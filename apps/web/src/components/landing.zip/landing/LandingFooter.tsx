import React from "react";
import Link from "next/link";
import { Github, Code, ExternalLink } from "lucide-react";
import { LocaleSwitcher } from "@/components/LocaleSwitcher";
import { ThemeToggle } from "@/components/ThemeToggle";
import { ColorThemeSwitcher } from "@/components/ColorThemeSwitcher";
import { useTranslations } from "next-intl";
import { Logo } from "@/components/Logo";

const apiDocsUrl = `${process.env.NEXT_PUBLIC_API_URL || "http://localhost:4000"}/docs`;

interface FooterLink {
  label: string;
  href: string;
  external?: boolean;
}

interface FooterColumn {
  title: string;
  links: FooterLink[];
}

const NAV_COLUMNS: FooterColumn[] = [
  {
    title: "Product",
    links: [
      { label: "Templates", href: "/explore" },
      { label: "Theme Gallery", href: "/themes" },
      { label: "Pricing", href: "/pricing" },
      { label: "Changelog", href: "/changelog" },
    ],
  },
  {
    title: "Developers",
    links: [
      { label: "API Docs", href: apiDocsUrl, external: true },
      { label: "LLMs.txt", href: "/llms.txt", external: true },
      { label: "REST API", href: apiDocsUrl, external: true },
      { label: "Open Source", href: "https://github.com/raaam02/sec-form", external: true },
    ],
  },
  {
    title: "Company",
    links: [
      { label: "About", href: "/about" },
      { label: "Blog", href: "/blog" },
      { label: "Privacy Policy", href: "/privacy" },
      { label: "Terms of Service", href: "/terms" },
    ],
  },
];

export function LandingFooter() {
  const t = useTranslations("Landing");

  return (
    <footer className="border-t border-border bg-card/60 relative overflow-hidden">
      {/* Top section */}
      <div className="container mx-auto px-4 sm:px-6 max-w-6xl relative z-10 pt-16">
        <div className="grid grid-cols-2 lg:grid-cols-[2fr_1fr_1fr_1fr] gap-10">

          {/* Brand column */}
          <div className="col-span-2 lg:col-span-1 flex flex-col gap-5">
            <Link href="/" className="flex items-center gap-2.5 w-fit">
              <Logo size="md" />
            </Link>

            <p className="text-[13px] text-muted-foreground leading-relaxed max-w-[260px]">
              The intelligent form builder powered by Gemini AI. Create, style, and analyze forms in minutes.
            </p>

            <div className="flex md:flex-col gap-5 justify-between pr-8">
              {/* Social links */}
              <div className="flex items-center gap-2">
                {[
                  { icon: Github, label: "GitHub", href: "https://github.com/raaam02/sec-form" },
                  { icon: Code, label: "API", href: apiDocsUrl },
                ].map(({ icon: Icon, label, href }) => (
                  <a
                    key={label}
                    href={href}
                    target="_blank"
                    rel="noopener noreferrer"
                    aria-label={label}
                    className="h-8 w-8 rounded-lg border border-border backdrop-blur-sm flex items-center justify-center text-muted-foreground hover:text-foreground hover:bg-accent transition-colors"
                  >
                    <Icon className="h-3.5 w-3.5" />
                  </a>
                ))}
              </div>

              <div className="flex flex-wrap items-center gap-2 pt-2">
                <LocaleSwitcher />
                <ThemeToggle />
                <ColorThemeSwitcher />
              </div>
            </div>
          </div>

          {/* Nav columns */}
          {NAV_COLUMNS.map((col) => (
            <div key={col.title} className="flex flex-col gap-4">
              <h4 className="text-[11px] font-black uppercase tracking-[0.15em] text-foreground">
                {col.title}
              </h4>
              <ul className="flex flex-col gap-2.5">
                {col.links.map(({ label, href, external }) => (
                  <li key={label}>
                    {external ? (
                      <a
                        href={href}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-[13px] text-muted-foreground hover:text-foreground transition-colors flex items-center gap-1"
                      >
                        {label}
                        <ExternalLink className="h-2.5 w-2.5 opacity-50" />
                      </a>
                    ) : (
                      <Link
                        href={href}
                        className="text-[13px] text-muted-foreground hover:text-foreground transition-colors"
                      >
                        {label}
                      </Link>
                    )}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>

      {/* Giant brand watermark */}
      <div
        className="inset-0 flex items-center justify-center overflow-hidden"
      >
        <span className="font-outfit leading-none translate-y-[7px] sm:translate-y-[14px] md:translate-y-[28px] font-black text-[22vw] sm:text-[18vw] tracking-tighter text-foreground/[0.035] dark:text-foreground/[0.04] whitespace-nowrap">
          Formu.AI
        </span>
      </div>

      {/* Bottom strip */}
      <div className="border-t border-border/50">
        <div className="container mx-auto px-4 sm:px-6 max-w-6xl py-5 flex flex-col sm:flex-row items-center justify-between gap-3 text-[12px] text-muted-foreground relative z-10">
          <span>{t("rights")}</span>
          <div className="flex items-center gap-4">
            <Link href="/privacy" className="hover:text-foreground transition-colors">Privacy</Link>
            <Link href="/terms" className="hover:text-foreground transition-colors">Terms</Link>
            <a href="/sitemap.xml" target="_blank" rel="noopener noreferrer" className="hover:text-foreground transition-colors">Sitemap</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
